package com.training.boothibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootHibernateApplication.class, args);
	}

}

