package com.training.micro.CatalogService.model;

public class TrainingList {

}
