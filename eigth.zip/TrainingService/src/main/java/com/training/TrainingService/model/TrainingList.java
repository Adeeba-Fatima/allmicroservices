package com.training.TrainingService.model;

import java.util.List;



public class TrainingList {
	private List<Training> tr;

	public List<Training> getTr() {
		return tr;
	}

	public void setTr(List<Training> tr) {
		this.tr = tr;
	}
	
}
